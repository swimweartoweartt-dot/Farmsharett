function saveUser(){
  const user = {
    fname: document.getElementById('fname').value,
    lname: document.getElementById('lname').value,
    email: document.getElementById('email').value,
    area: document.getElementById('area').value
  };
  localStorage.setItem("user", JSON.stringify(user));
  alert("Saved!");
}

// Sample chart
const ctx = document.getElementById('chart');
new Chart(ctx, {
  type: 'line',
  data: {
    labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    datasets: [{
      label: 'Tomato Price',
      data: [8,7,9,8,10,11,10],
    }]
  }
});
